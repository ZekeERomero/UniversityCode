#ifndef _IORUNTIME_H_
#define _IORUNTIME_H_

#include "scanType.h"
#include "symbolTable.h"
#include "parser.tab.h"
#include "string.h"
#include "semantic.h"
#include <stdlib.h>
#include <stdio.h>
#include <sstream>

using namespace std;

//void IORuntime(SymbolTable* symbolTable);

#endif
