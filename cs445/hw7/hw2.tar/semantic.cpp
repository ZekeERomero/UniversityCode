#include "semantic.h"

int compoundNum = 0;

extern int numErrors, numWarnings;

void error(const char *msg, const char* name, int line)
{
	printf("ERROR(%d): %s: %s\n", line, msg, name);
	numErrors++;
}

void semanticAnalysis(TreeNode *tree, SymbolTable *symbolTable)
{
	while (tree != NULL)
	{
		char *expType;
		if (tree->expType == Integer)
			expType = strdup("int");
		else if (tree->expType == Boolean)
			expType = strdup("bool");
		else if (tree->expType == Char)
			expType = strdup("char");
		else if (tree->expType == Void)
			expType = strdup("void");

		switch (tree->nodekind)
		{
			case StmtK:
				switch (tree->subkind.stmt)
				{
					case CompoundK:
						if (!tree->notScope)
						{
							std::ostringstream oss;
							oss << "New Compound #" << compoundNum;
							std::string str = oss.str();
//							printf("Made a new scope \"%s\" ", str.c_str());
							symbolTable->enter(str);
							compoundNum++;
						}
					break;
					case ForK:
						std::ostringstream oss;
						oss << "New Compound #" << compoundNum;
						std::string str = oss.str();
//						printf("Made a new scope \"%s\" ", str.c_str());
						symbolTable->enter(str);
						compoundNum++;

						//Do something to its compound child
						if (tree->child[2]->nodekind == StmtK)
						{
							if (tree->child[2]->subkind.stmt == CompoundK)
							{
								tree->child[2]->notScope = true;
							}
						}
					break;
				}
			break;
			case ExpK:
				if (tree->subkind.exp == AssignK)
				{
					std::stringstream name;
					if (tree->child[0]->subkind.exp == OpK)
						name.str(tree->child[0]->child[0]->attr.name);
					else
						name.str(tree->child[0]->attr.name);
					void *returnVar = symbolTable->lookup(name.str());
					std::string id = name.str();

					if (returnVar == NULL)
					{
						std::ostringstream errorText;
						errorText << "Symbol '" << name.str() << "' is not declared. ";

						error(errorText.str().c_str(), id.c_str(), tree->lineno);
					}
					else
					{
//						printf("Found var %s ", id.c_str());
					}
				}
			break;
			case DeclK:
				
				if (tree->subkind.decl == VarK)
				{
					std::stringstream name;
					name.str(tree->attr.name);

					void *var;
					if (tree->child[0] != NULL)
					{
						var = tree->child[0];
					}
					else
					{
						var = operator new(1);
					}

					if (compoundNum > 0)
					{
						if(!symbolTable->insert(name.str(), var))
						{
							std::ostringstream errorText;
							errorText << "Symbol '" << name.str() << "' is already declared at line " << 45 << ".";

							error(errorText.str().c_str(), tree->attr.name, tree->lineno);
						}
						else
						{
//							printf("Declared %s as a new variable of type %s ", tree->attr.name, expType);
						}
					}
					else
					{
						if(!symbolTable->insertGlobal(name.str(), var))
						{
							error("GLOBAL Var was already declared ", tree->attr.name, tree->lineno);
						}
						else
						{
//							printf("Declared %s as a new GLOBAL variable of type %s ", tree->attr.name, expType);
						}
					}
				}
				if (tree->subkind.decl == FuncK)
				{
					std::ostringstream oss;
					oss << "New Compound #" << compoundNum;
					std::string str = oss.str();
//					printf("Made a new scope \"%s\" ", str.c_str());
					symbolTable->enter(str);
					compoundNum++;

					//Do something to its compound child
					tree->child[1]->notScope = true;
				}
				if (tree->subkind.decl == ParamK)
				{
					std::stringstream name;
					name.str(tree->attr.name);

					void* var;
					if (tree->child[0] != NULL)
					{
						var = tree->child[0];
					}
					else
					{
						var = operator new(1);
					}
					
					std::ostringstream errorText;
                                        errorText << "Symbol '" << name.str() << "' is already declared at line " << 45;

					if(!symbolTable->insert(name.str(), var))
					{
						error(errorText.str().c_str(), tree->attr.name, tree->lineno);
					}
					else
					{
//						printf("Declared %s as a new variable of type %s ", tree->attr.name, expType);
					}
				}

			break;
		}
		

		//printf("[line: %d]\n", tree->lineno);

		int i;
		for (i = 0; i < MAXCHILDREN; i++)
		{
			semanticAnalysis(tree->child[i], symbolTable);
		}

		//Leave Compound Scope
		if (tree->nodekind == StmtK)
		{
			if ((tree->subkind.stmt == CompoundK && !tree->notScope) || tree->subkind.stmt == ForK)
			{
				if (compoundNum > 0)
				{
//					printf("Removing previous scope. \n");
					symbolTable->leave();
					compoundNum--;
				}
			}
		}
		if (tree->nodekind == DeclK)
		{
			if (tree->subkind.decl == FuncK)
			{
				if (compoundNum > 0)
				{
//					printf("Removing previous scope. \n");
					symbolTable->leave();
					compoundNum--;
				}
			}
		}

		tree = tree->sibling; 
	}
}
