nclude <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(void) {

        int second = 100;
        double minute = 60*second;
        int temp = -1;
        int counter = 0;

  for(int i = 0; i < (5*minute); i++) {

        /* write 10 lines of text into the file stream*/

                        counter++;

                        printf("counter - %d", counter);
                        printf("\n");

                for (int c = 1; c <= 2226; c++)
       for (int d = 1; d <= 2226; d++)
       {}

  }

  return 0;
}

