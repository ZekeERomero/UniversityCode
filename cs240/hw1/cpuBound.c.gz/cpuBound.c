#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(void) {

	FILE * fp;
   /* open the file for writing*/
  fp = fopen ("Sample.txt","w");

	int second = 100;
	double minute = 60*second;
	int temp = -1;

  for(int i = 0; i < (0.5*minute); i++) {

  	/* write 10 lines of text into the file stream*/
  	fprintf (fp, "This is line %d\n",i + 1);

			printf("printed %d", i/100);
			printf("\n");
 
  	
  
		for (int c = 1; c <= 1426; c++)
       for (int d = 1; d <= 1426; d++)
       {}

  }

	fclose (fp);
  return 0;
}
